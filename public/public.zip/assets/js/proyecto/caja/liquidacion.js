eventosliquidacion();

var datacompras;

function eventosliquidacion(){

}

$(function(){
	setview('#formliquidacion','#content','/Caja/Liquidacion');
})